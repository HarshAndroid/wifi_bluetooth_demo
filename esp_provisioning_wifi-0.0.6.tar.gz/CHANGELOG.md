## 0.0.1

* Alpha: First release

## 0.0.2

* Alpha: Improvements to pub.dev score

## 0.0.3

* Alpha: Improvements to pub.dev score (again)

## 0.0.4

* Alpha: Correctly report on provisioning success

## 0.0.5

* Alpha: Add permission-handler and update to latest flutter_esp_ble_prov

## 0.0.6

* Alpha: Fix iOS compilation errors
