// ignore_for_file: constant_identifier_names

/// Time before a request to the FlutterEspBleProv plugin times out, in seconds
const TIMEOUT = 20;
