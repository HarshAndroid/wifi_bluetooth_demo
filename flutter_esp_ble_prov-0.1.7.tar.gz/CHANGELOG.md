## 0.1.7

* Minor fixes

## 0.1.6

* Minor fixes

## 0.1.5

* Fix for permissions in Android >= T

## 0.1.4

* Fixed missing dependencies

## 0.1.3

* Add additional provisioning states
* Remove requirement for embedded library

## 0.1.2

* Update to flutter stable 3.7.0

## 0.1.1

* Minor Updates

## 0.1.0

* Add iOS support
* Bump minor version, we are now feature complete

## 0.0.6

* Correct version-based permission handling on Android

## 0.0.5

* Minor updates

## 0.0.4

* Minor updates

## 0.0.3

* Minor updates

## 0.0.2

* Minor updates


## 0.0.1

* Alpha: Android only support
