package how.virc.flutter_esp_ble_prov_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
